export const cardInfo = (state) => state.cardInfo

export const uid = (state) => state.uid

export const bankCode = (state) => state.bankCode

export const goodsName = (state) => state.goodsName

export const pointsType = (state) => state.pointsType
