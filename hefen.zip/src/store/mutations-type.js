export const SET_CARD_INFO = 'SET_CARD_INFO'

export const SET_UID = 'SET_UID'

export const SET_BANK_CODE = 'SET_BANK_CODE'

export const SET_GOODS_NAME = 'SET_GOODS_NAME'

export const SET_POINTS_TYPE = 'SET_POINTS_TYPE'
