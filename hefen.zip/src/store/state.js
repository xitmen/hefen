const state = {
  cardInfo: {},
  uid: '',
  bankCode: '',
  goodsName: {},
  pointsType: ''
}

export default state
