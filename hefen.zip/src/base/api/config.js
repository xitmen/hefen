export const HOST_NAME = 'http://api.boxfen.com:8090/'

export const SUCCESS = 1

export const APPLY_CARD = 'https://interacts.hq.vidata.com.cn/h5/card-platform/index.html?source=18432'
