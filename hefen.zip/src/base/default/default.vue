<template>
  <div class="default">
    <img src="./default.png" width="210px" height="210px" alt="">
  </div>
</template>

<script>
export default {
  name: 'default'
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">
  @import "~common/stylus/variable"
  @import "~common/stylus/mixin"
  .default
    width 100%
    text-align center

</style>
